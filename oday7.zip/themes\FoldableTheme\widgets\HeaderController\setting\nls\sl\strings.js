define({
  "group": "Ime",
  "openAll": "Odpri vse na eni plošči",
  "dropDown": "Prikaži v spustnem meniju",
  "noGroup": "Skupina pripomočkov ni nastavljena",
  "groupSetLabel": "Nastavi lastnosti skupin pripomočkov"
});