define({
  "_widgetLabel": "Controller van koptekst",
  "signin": "Aanmelden",
  "signout": "Meld u af",
  "about": "Over",
  "signInTo": "Meld u aan bij",
  "cantSignOutTip": "Deze functie is niet beschikbaar in de voorbeeldmodus.",
  "more": "meer"
});