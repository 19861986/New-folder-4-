define({
  "group": "Tên",
  "openAll": "Mở tất cả trong bảng điều khiển",
  "dropDown": "Hiển thị trong menu xổ xuống",
  "noGroup": "Không có nhóm tiện ích nào được thiết lập.",
  "groupSetLabel": "Thiết lập thuộc tính nhóm tiện ích"
});