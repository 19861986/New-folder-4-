define({
  "group": "Ad",
  "openAll": "Tümünü tek panelde aç",
  "dropDown": "Açılır menüde göster",
  "noGroup": "Ayarlanmış araç grubu yok.",
  "groupSetLabel": "Araç grubu özelliklerini ayarla"
});