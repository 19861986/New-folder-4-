define({
  "_themeLabel": "फोल्डेबल थीम",
  "_layout_default": "डिफ़ॉल्ट रूपरेखा",
  "_layout_layout1": "रूपरेखा 1"
});